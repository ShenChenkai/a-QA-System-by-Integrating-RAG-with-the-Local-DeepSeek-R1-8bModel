# test_import.py
from document_processor import DocumentProcessor

print("导入成功！")