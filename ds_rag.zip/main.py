import sys
from pathlib import Path
from config import Config
from document_processor import DocumentProcessor
from vector_db import VectorDB
from model_integration import ModelIntegration
from rag_chain import RAGChain
from utils import setup_logging, format_response
import logging

def main():
    setup_logging(Config.LOG_LEVEL)
    logger = logging.getLogger(__name__)
    
    try:
        # 添加项目根目录到Python路径
        project_root = str(Path(__file__).parent)
        sys.path.append(project_root)
        
        # 初始化模块
        doc_processor = DocumentProcessor(Config)
        documents = doc_processor.process_pdf_directory()
        
        vector_db = VectorDB(Config)
        vector_db.initialize(documents)
        retriever = vector_db.get_retriever()
        
        model = ModelIntegration(Config)
        model.initialize()
        llm = model.get_llm()
        
        rag_chain = RAGChain(Config, llm, retriever)
        rag_chain.initialize()
        
        # 交互式查询（可取消注释以启用）
        # while True:
        #     user_query = input("\n请输入问题（输入'退出'结束）: ")
        #     if user_query.lower() in ["退出", "q"]:
        #         break
        #     result = rag_chain.run_query(user_query)
        #     print(format_response(result))
        
        # 示例查询（自动执行）
        sample_query = "浙江大学本科辅修的申请条件是什么？"
        logger.info(f"执行示例查询: {sample_query}")
        result = rag_chain.run_query(sample_query)
        formatted_result = format_response(result)
        
        # 打印结果
        print("\n" + "="*50)
        print(f"问题: {formatted_result['question']}")
        print("\n回答:")
        print(formatted_result['answer'])
        
        print("\n" + "-"*50)
        print("引用文档:")
        for i, doc in enumerate(formatted_result["source_documents"]):
            print(f"\n来源文档 {i+1} ({doc['metadata']['source']}):")
            print(doc["content"])
        
        print("\n" + "="*50)
        
    except Exception as e:
        logger.error(f"程序运行出错: {e}", exc_info=True)
        print(f"错误: {e}")

if __name__ == "__main__":
    main()